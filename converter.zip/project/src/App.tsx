import React, { useState } from 'react';
import { Calculator, Github, ExternalLink } from 'lucide-react';
import { ConversionCategory, ConversionResult, FavoriteConversion } from './types';
import { conversionCategories } from './data/conversions';
import { useLocalStorage } from './hooks/useLocalStorage';
import { CategoryCard } from './components/CategoryCard';
import { Converter } from './components/Converter';
import { ConversionHistory } from './components/ConversionHistory';

function App() {
  const [activeCategory, setActiveCategory] = useState<ConversionCategory>(conversionCategories[0]);
  const [history, setHistory] = useLocalStorage<ConversionResult[]>('conversion-history', []);
  const [favorites, setFavorites] = useLocalStorage<FavoriteConversion[]>('conversion-favorites', []);

  const handleConversionComplete = (result: ConversionResult) => {
    setHistory(prev => {
      const filtered = prev.filter(item => 
        !(item.category === result.category && 
          item.fromUnit === result.fromUnit && 
          item.toUnit === result.toUnit &&
          item.fromValue === result.fromValue)
      );
      return [result, ...filtered];
    });
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleApplyConversion = (result: ConversionResult) => {
    const category = conversionCategories.find(cat => cat.name === result.category);
    if (category) {
      setActiveCategory(category);
    }
  };

  const handleToggleFavorite = (result: ConversionResult) => {
    const favoriteId = `${result.category}-${result.fromUnit}-${result.toUnit}`;
    const existingIndex = favorites.findIndex(fav => fav.id === favoriteId);
    
    if (existingIndex >= 0) {
      setFavorites(prev => prev.filter((_, index) => index !== existingIndex));
    } else {
      const newFavorite: FavoriteConversion = {
        id: favoriteId,
        category: result.category,
        fromUnit: result.fromUnit,
        toUnit: result.toUnit,
        name: `${result.fromUnit} to ${result.toUnit}`
      };
      setFavorites(prev => [newFavorite, ...prev]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/20 backdrop-blur-md border-b border-white/30 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl text-white">
                <Calculator size={24} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">Unit Converter Pro</h1>
                <p className="text-sm text-gray-600">Professional unit conversion tool</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg hover:bg-white/20 transition-all duration-200"
              >
                <Github size={16} />
                <span className="hidden sm:inline text-sm">GitHub</span>
              </a>
              <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200">
                <ExternalLink size={16} />
                <span className="hidden sm:inline text-sm">Share</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Category Selection */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Conversion Categories</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {conversionCategories.map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                isActive={activeCategory.id === category.id}
                onClick={() => setActiveCategory(category)}
              />
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Converter */}
          <div className="lg:col-span-2">
            <Converter
              category={activeCategory}
              onConversionComplete={handleConversionComplete}
              favorites={favorites}
            />
          </div>

          {/* History Sidebar */}
          <div className="lg:col-span-1">
            <ConversionHistory
              history={history}
              favorites={favorites}
              onClearHistory={handleClearHistory}
              onApplyConversion={handleApplyConversion}
              onToggleFavorite={handleToggleFavorite}
            />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <p className="text-gray-600 text-sm">
              Built with React, TypeScript, and Tailwind CSS • 
              <span className="ml-1">Supports {conversionCategories.length} conversion categories</span>
            </p>
            <div className="mt-3 flex justify-center space-x-6 text-xs text-gray-500">
              <span>Real-time conversion</span>
              <span>•</span>
              <span>Conversion history</span>
              <span>•</span>
              <span>Favorites system</span>
              <span>•</span>
              <span>Copy to clipboard</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
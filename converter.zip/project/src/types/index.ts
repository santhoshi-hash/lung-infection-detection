export interface Unit {
  name: string;
  symbol: string;
  factor: number;
  offset?: number;
}

export interface ConversionCategory {
  id: string;
  name: string;
  icon: string;
  units: Unit[];
}

export interface ConversionResult {
  id: string;
  category: string;
  fromUnit: string;
  toUnit: string;
  fromValue: number;
  toValue: number;
  timestamp: Date;
}

export interface FavoriteConversion {
  id: string;
  category: string;
  fromUnit: string;
  toUnit: string;
  name: string;
}
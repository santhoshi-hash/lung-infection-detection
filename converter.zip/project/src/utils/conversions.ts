import { Unit } from '../types';

export const convertValue = (
  value: number,
  fromUnit: Unit,
  toUnit: Unit,
  category: string
): number => {
  if (category === 'temperature') {
    return convertTemperature(value, fromUnit, toUnit);
  }
  
  const baseValue = value * fromUnit.factor;
  return baseValue / toUnit.factor;
};

const convertTemperature = (value: number, fromUnit: Unit, toUnit: Unit): number => {
  // Convert to Celsius first
  let celsius: number;
  
  switch (fromUnit.symbol) {
    case '°C':
      celsius = value;
      break;
    case '°F':
      celsius = (value - 32) * 5 / 9;
      break;
    case 'K':
      celsius = value - 273.15;
      break;
    case '°R':
      celsius = (value - 491.67) * 5 / 9;
      break;
    default:
      celsius = value;
  }
  
  // Convert from Celsius to target unit
  switch (toUnit.symbol) {
    case '°C':
      return celsius;
    case '°F':
      return celsius * 9 / 5 + 32;
    case 'K':
      return celsius + 273.15;
    case '°R':
      return celsius * 9 / 5 + 491.67;
    default:
      return celsius;
  }
};

export const formatNumber = (value: number): string => {
  if (Math.abs(value) >= 1e6) {
    return value.toExponential(6);
  }
  
  if (Math.abs(value) < 0.000001 && value !== 0) {
    return value.toExponential(6);
  }
  
  return value.toFixed(8).replace(/\.?0+$/, '');
};
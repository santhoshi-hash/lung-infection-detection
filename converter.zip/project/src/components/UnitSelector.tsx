import React, { useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import { Unit } from '../types';

interface UnitSelectorProps {
  units: Unit[];
  selectedUnit: Unit;
  onSelect: (unit: Unit) => void;
  label: string;
}

export const UnitSelector: React.FC<UnitSelectorProps> = ({ units, selectedUnit, onSelect, label }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredUnits = units.filter(unit =>
    unit.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    unit.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:bg-white/20 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
      >
        <div className="flex items-center space-x-2">
          <span className="font-medium">{selectedUnit.name}</span>
          <span className="text-sm text-gray-500">({selectedUnit.symbol})</span>
        </div>
        <ChevronDown 
          size={16} 
          className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} 
        />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute top-full left-0 right-0 mt-2 bg-white/95 backdrop-blur-md border border-white/30 rounded-xl shadow-2xl z-20 max-h-80 overflow-hidden">
            <div className="p-3 border-b border-gray-200/50">
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search units..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-gray-50/50 border border-gray-200/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-sm"
                />
              </div>
            </div>
            <div className="max-h-60 overflow-y-auto">
              {filteredUnits.map((unit) => (
                <button
                  key={unit.name}
                  onClick={() => {
                    onSelect(unit);
                    setIsOpen(false);
                    setSearchTerm('');
                  }}
                  className={`w-full flex items-center justify-between px-4 py-3 hover:bg-blue-50/50 transition-colors duration-150 ${
                    selectedUnit.name === unit.name ? 'bg-blue-100/50 text-blue-700' : 'text-gray-700'
                  }`}
                >
                  <span className="font-medium">{unit.name}</span>
                  <span className="text-sm text-gray-500">{unit.symbol}</span>
                </button>
              ))}
              {filteredUnits.length === 0 && (
                <div className="px-4 py-6 text-center text-gray-500 text-sm">
                  No units found
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
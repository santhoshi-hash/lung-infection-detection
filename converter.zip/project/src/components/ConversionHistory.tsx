import React from 'react';
import { Clock, Trash2, Star } from 'lucide-react';
import { ConversionResult, FavoriteConversion } from '../types';
import { formatNumber } from '../utils/conversions';

interface ConversionHistoryProps {
  history: ConversionResult[];
  favorites: FavoriteConversion[];
  onClearHistory: () => void;
  onApplyConversion: (result: ConversionResult) => void;
  onToggleFavorite: (result: ConversionResult) => void;
}

export const ConversionHistory: React.FC<ConversionHistoryProps> = ({
  history,
  favorites,
  onClearHistory,
  onApplyConversion,
  onToggleFavorite
}) => {
  const isFavorite = (result: ConversionResult) => {
    return favorites.some(fav => 
      fav.category === result.category && 
      fav.fromUnit === result.fromUnit && 
      fav.toUnit === result.toUnit
    );
  };

  if (history.length === 0) {
    return (
      <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Clock size={20} className="text-gray-600" />
          <h3 className="font-semibold text-gray-800">Recent Conversions</h3>
        </div>
        <p className="text-gray-500 text-center py-8">No conversions yet</p>
      </div>
    );
  }

  return (
    <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Clock size={20} className="text-gray-600" />
          <h3 className="font-semibold text-gray-800">Recent Conversions</h3>
        </div>
        <button
          onClick={onClearHistory}
          className="flex items-center space-x-1 text-red-500 hover:text-red-600 transition-colors duration-200"
        >
          <Trash2 size={16} />
          <span className="text-sm">Clear</span>
        </button>
      </div>
      
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {history.slice(0, 10).map((result) => (
          <div
            key={result.id}
            className="group flex items-center justify-between p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-all duration-200 cursor-pointer"
            onClick={() => onApplyConversion(result)}
          >
            <div className="flex-1">
              <div className="flex items-center space-x-2 text-sm">
                <span className="font-medium">{formatNumber(result.fromValue)}</span>
                <span className="text-gray-500">{result.fromUnit}</span>
                <span className="text-gray-400">→</span>
                <span className="font-medium">{formatNumber(result.toValue)}</span>
                <span className="text-gray-500">{result.toUnit}</span>
              </div>
              <div className="text-xs text-gray-400 mt-1">
                {result.category} • {new Date(result.timestamp).toLocaleDateString()}
              </div>
            </div>
            
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite(result);
              }}
              className={`p-1 rounded-md transition-colors duration-200 ${
                isFavorite(result)
                  ? 'text-yellow-500 hover:text-yellow-600'
                  : 'text-gray-400 hover:text-yellow-500'
              }`}
            >
              <Star size={16} fill={isFavorite(result) ? 'currentColor' : 'none'} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
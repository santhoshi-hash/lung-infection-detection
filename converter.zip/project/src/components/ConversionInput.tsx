import React from 'react';
import { Copy, CheckCircle } from 'lucide-react';
import { Unit } from '../types';
import { formatNumber } from '../utils/conversions';

interface ConversionInputProps {
  value: string;
  onChange: (value: string) => void;
  unit: Unit;
  label: string;
  readOnly?: boolean;
  onCopy?: () => void;
  showCopyButton?: boolean;
  copySuccess?: boolean;
}

export const ConversionInput: React.FC<ConversionInputProps> = ({ 
  value, 
  onChange, 
  unit, 
  label, 
  readOnly = false,
  onCopy,
  showCopyButton = false,
  copySuccess = false
}) => {
  const displayValue = readOnly && value ? formatNumber(parseFloat(value)) : value;

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      <div className="relative">
        <input
          type="number"
          value={displayValue}
          onChange={(e) => onChange(e.target.value)}
          readOnly={readOnly}
          placeholder="Enter value"
          className={`
            w-full px-4 py-4 pr-20 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl 
            text-lg font-medium transition-all duration-200
            ${readOnly 
              ? 'cursor-default text-gray-800 bg-blue-50/50' 
              : 'focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:bg-white/20'
            }
          `}
        />
        <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center space-x-2">
          <span className="text-sm font-medium text-gray-600">{unit.symbol}</span>
          {showCopyButton && onCopy && (
            <button
              onClick={onCopy}
              className="p-1 hover:bg-white/20 rounded-md transition-colors duration-200"
              title="Copy value"
            >
              {copySuccess ? (
                <CheckCircle size={16} className="text-green-500" />
              ) : (
                <Copy size={16} className="text-gray-500 hover:text-gray-700" />
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import * as Icons from 'lucide-react';
import { ConversionCategory } from '../types';

interface CategoryCardProps {
  category: ConversionCategory;
  isActive: boolean;
  onClick: () => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ category, isActive, onClick }) => {
  const IconComponent = Icons[category.icon as keyof typeof Icons] as React.ComponentType<{ size?: number; className?: string }>;

  return (
    <button
      onClick={onClick}
      className={`
        group relative overflow-hidden rounded-2xl p-6 transition-all duration-300 transform hover:scale-105
        ${isActive 
          ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-2xl' 
          : 'bg-white/10 backdrop-blur-sm border border-white/20 text-gray-700 hover:bg-white/20 hover:border-white/30'
        }
      `}
    >
      <div className="flex flex-col items-center space-y-3">
        <div className={`
          p-3 rounded-xl transition-all duration-300
          ${isActive 
            ? 'bg-white/20' 
            : 'bg-gradient-to-br from-blue-500/10 to-purple-600/10 group-hover:from-blue-500/20 group-hover:to-purple-600/20'
          }
        `}>
          <IconComponent size={24} className="transition-transform duration-300 group-hover:scale-110" />
        </div>
        <span className="font-semibold text-sm">{category.name}</span>
      </div>
      
      {isActive && (
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 translate-x-full group-hover:translate-x-[-200%] transition-transform duration-1000" />
      )}
    </button>
  );
};
import React, { useState, useEffect } from 'react';
import { ArrowUpDown } from 'lucide-react';
import { ConversionCategory, ConversionResult, FavoriteConversion, Unit } from '../types';
import { convertValue } from '../utils/conversions';
import { UnitSelector } from './UnitSelector';
import { ConversionInput } from './ConversionInput';

interface ConverterProps {
  category: ConversionCategory;
  onConversionComplete: (result: ConversionResult) => void;
  favorites: FavoriteConversion[];
}

export const Converter: React.FC<ConverterProps> = ({ category, onConversionComplete, favorites }) => {
  const [fromUnit, setFromUnit] = useState<Unit>(category.units[0]);
  const [toUnit, setToUnit] = useState<Unit>(category.units[1] || category.units[0]);
  const [fromValue, setFromValue] = useState<string>('');
  const [toValue, setToValue] = useState<string>('');
  const [copySuccess, setCopySuccess] = useState(false);

  useEffect(() => {
    if (fromValue && !isNaN(parseFloat(fromValue))) {
      const result = convertValue(parseFloat(fromValue), fromUnit, toUnit, category.id);
      setToValue(result.toString());
      
      const conversionResult: ConversionResult = {
        id: Date.now().toString(),
        category: category.name,
        fromUnit: fromUnit.symbol,
        toUnit: toUnit.symbol,
        fromValue: parseFloat(fromValue),
        toValue: result,
        timestamp: new Date()
      };
      
      onConversionComplete(conversionResult);
    } else {
      setToValue('');
    }
  }, [fromValue, fromUnit, toUnit, category, onConversionComplete]);

  const handleSwapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
    setFromValue(toValue);
  };

  const handleCopyResult = async () => {
    if (toValue) {
      try {
        await navigator.clipboard.writeText(toValue);
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
      } catch (err) {
        console.error('Failed to copy to clipboard:', err);
      }
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{category.name} Converter</h2>
        <p className="text-gray-600">Convert between different {category.name.toLowerCase()} units</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <UnitSelector
            units={category.units}
            selectedUnit={fromUnit}
            onSelect={setFromUnit}
            label="From"
          />
          <ConversionInput
            value={fromValue}
            onChange={setFromValue}
            unit={fromUnit}
            label="Value"
          />
        </div>

        <div className="space-y-4">
          <UnitSelector
            units={category.units}
            selectedUnit={toUnit}
            onSelect={setToUnit}
            label="To"
          />
          <ConversionInput
            value={toValue}
            onChange={() => {}}
            unit={toUnit}
            label="Result"
            readOnly
            showCopyButton
            onCopy={handleCopyResult}
            copySuccess={copySuccess}
          />
        </div>
      </div>

      <div className="flex justify-center">
        <button
          onClick={handleSwapUnits}
          className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-105 shadow-lg"
        >
          <ArrowUpDown size={18} />
          <span>Swap Units</span>
        </button>
      </div>
    </div>
  );
};